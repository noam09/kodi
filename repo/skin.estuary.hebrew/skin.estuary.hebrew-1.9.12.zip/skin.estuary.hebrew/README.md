# skin.estuary.hebrew
A clone of Kodi Krypton's default Estuary skin with Hebrew font files.

This repository will be synced with [skin.estuary](https://github.com/xbmc/xbmc/tree/Krypton/addons/skin.estuary) on a daily basis. 

Font sources:
* [Noto](https://www.google.com/get/noto/)
* [Heebo (Roboto with Hebrew glyphs)](https://fonts.google.com/specimen/Heebo)

Original `Noto-Regular` and `Noto-Bold` fonts merged with Hebrew Noto fonts using [fonttools](https://github.com/fonttools/fonttools) `pyftmerge`.
