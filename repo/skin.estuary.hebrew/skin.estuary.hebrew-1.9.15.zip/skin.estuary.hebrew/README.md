# skin.estuary.hebrew
A clone of Kodi Krypton's default Estuary skin with Hebrew-capable font files. This allows media with Hebrew titles and tags to be displayed properly even when using an English user interface.

Download the latest ZIP [here](https://github.com/noam09/kodi/tree/master/repo/skin.estuary.hebrew).

This repository will be synced with [skin.estuary](https://github.com/xbmc/xbmc/tree/Krypton/addons/skin.estuary) on a daily basis. 

Font sources:
* [Noto](https://www.google.com/get/noto/)
* [Heebo (Roboto with Hebrew glyphs)](https://fonts.google.com/specimen/Heebo)

Original `Noto-Regular` and `Noto-Bold` fonts merged with Hebrew Noto fonts using [fonttools](https://github.com/fonttools/fonttools) `pyftmerge`.
